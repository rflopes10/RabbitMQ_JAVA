var amqp = require('amqplib/callback_api');

amqp.connect('amqp://localhost:5672', function (err, conn) {
    conn.createChannel(function (err, ch) {
        var q = 'teste';
        var msg = 'eai mlk!';
        ch.assertQueue(q, { durable: false });     
        ch.sendToQueue(q, new Buffer(msg));
        console.log(" [x] Enviado %s", msg);
    });
    setTimeout(function () { conn.close(); process.exit(0) }, 500);
});